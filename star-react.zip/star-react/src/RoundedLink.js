function RoundedLink(props) {
     const themeClasses =
          props.theme === "white"
               ? "border-white text-white"
               : "border-black text-black";
     return (
          <a
               href="props.linkUrl"
               className={
                    "border font-semibold rounded-full flex-shrink-0 tracking-wide px-4 py-2 text-sm " +
                    themeClasses
               }
          >
               {props.linkText}
          </a>
     );
}

export default RoundedLink;
