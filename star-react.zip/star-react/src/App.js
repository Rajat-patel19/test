import Nav from "./Nav";
import Header from "./Header";
import HeroSection from "./HeroSection";

function App() {
     return (
          <div className="font-sans">
               <Nav />
               <Header />
               <HeroSection />
          </div>
     );
}

export default App;
