import RoundedLink from "./RoundedLink";

function Header() {
     return (
          <div className="sticky top-0 flex justify-between items-center bg-primary-400 px-4 py-2">
               <p className="text-13 text-white font-bold">
                    STARBUCKS® REWARDS
               </p>
               <RoundedLink
                    linkText="Join in the app"
                    linkUrl="https://starbucks.app.link/VLa2I3inh9"
                    theme="white"
               />
          </div>
     );
}

export default Header;
