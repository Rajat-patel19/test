function HeroSection() {
     return (
          <div className="aspect-w-3 aspect-h-4">
               <div className="bg-cover bg-no-repeat bg-hero">
                    <h1>FREE COFFEE IS A TAP AWAY</h1>
               </div>
          </div>
     );
}

export default HeroSection;
